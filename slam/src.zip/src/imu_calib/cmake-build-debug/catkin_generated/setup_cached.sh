#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/itcast/Documents/itheima_ws/src/imu_calib/cmake-build-debug/devel:$CMAKE_PREFIX_PATH"
export LD_LIBRARY_PATH="/home/itcast/Documents/itheima_ws/src/imu_calib/cmake-build-debug/devel/lib:$LD_LIBRARY_PATH"
export PKG_CONFIG_PATH="/home/itcast/Documents/itheima_ws/src/imu_calib/cmake-build-debug/devel/lib/pkgconfig:$PKG_CONFIG_PATH"
export ROSLISP_PACKAGE_DIRECTORIES="/home/itcast/Documents/itheima_ws/src/imu_calib/cmake-build-debug/devel/share/common-lisp:$ROSLISP_PACKAGE_DIRECTORIES"
export ROS_PACKAGE_PATH="/home/itcast/Desktop/heima_ws/src/imu_calib:/home/itcast/Documents/itheima_ws/src/imu_calib:$ROS_PACKAGE_PATH"