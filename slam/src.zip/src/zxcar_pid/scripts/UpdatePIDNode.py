#! /usr/bin/env python
#encoding:utf-8
from zxcar_pid.cfg import zxcar_PIDConfig
from dynamic_reconfigure.server import Server
from std_msgs.msg import Float32MultiArray
import rospy

class UpdatePID():

    def __init__(self):
        rospy.init_node("update_pid")

        rospy.on_shutdown(self.shutdown)

        # 执行频率
        rate = rospy.Rate(20)

        # 声明一个消息发布者， 将消息发布给zxcar_driver
        self.publisher_pid = rospy.Publisher("/zxcar/pid",Float32MultiArray,queue_size=100)

        # 启动参数配置服务器         当参数发生变化时的回调
        Server(zxcar_PIDConfig,self.dynamic_callback)

        # 打印一个启动成功的日志
        rospy.loginfo("updatePIDnode start success! Bring up rqt_reconfigure to control the pid...")

        # 让ros节点跑起来
        while not rospy.is_shutdown():

            rate.sleep()


    def dynamic_callback(self,config,level):
        """
        当参数发生变化时的回调函数
        :param config: 配置文件
        :param level:  修改的状态
        :return:
        """
        # 封装消息
        kp = config["p"]
        ki = config["i"]
        kd = config["d"]

        pidmsg = Float32MultiArray()
        pidmsg.data.append(kp)
        pidmsg.data.append(ki)
        pidmsg.data.append(kd)

        # 将消息发布出去
        self.publisher_pid.publish(pidmsg)
        print(config,level)
        return config

    def shutdown(self):
        print("stop robot...")

if __name__ == '__main__':
    UpdatePID()