#! /usr/bin/env python
# encoding: utf-8
import rospy
from geometry_msgs.msg import Twist
import cv2 as cv


def shutdown():
    twist = Twist()
    twist.linear.x = 0
    twist.angular.z = 0
    cmd_vel_Publisher.publish(twist)
    print "stop car..."

if __name__ == '__main__':
    rospy.init_node("black_follow")

    # 当程序退出
    rospy.on_shutdown(shutdown);

    # ros控制的频率
    rate = rospy.Rate(100)

    # 定义publisher : cmd_vel
    cmd_vel_Publisher = rospy.Publisher("/cmd_vel",Twist,queue_size=1)


    capture = cv.VideoCapture(0)
    print capture.isOpened()
    ok,frame = capture.read()
    height,width = frame.shape[0:2]

    while not rospy.is_shutdown():
        # twist = Twist()
        # twist.linear.x = 1
        # cmd_vel_Publisher.publish(twist)



        # 识别黑色
        hsv_img = cv.cvtColor(frame,cv.COLOR_BGR2HSV)
        lowerb = (0,0,0)
        upperb = (180,255,70)
        mask = cv.inRange(hsv_img,lowerb,upperb)
        mask = mask[int(height/2):,:]
        frame = frame[int(height/2):,:]
        # 找出最大的轮廓
        maxArea = 0
        maxIndex = 0
        _,contours,_ = cv.findContours(mask,cv.RETR_EXTERNAL,cv.CHAIN_APPROX_SIMPLE)

        if len(contours) <=0:
            print "m"
            continue

        for i,c in enumerate(contours):
            area = cv.contourArea(c)
            if area > maxArea:
                maxArea = area
                maxIndex = i

        ((x,y),(w,h),angel) = cv.minAreaRect(contours[maxIndex])
        cv.circle(frame,(int(x),int(y)),5,(0,255,255),-1)
        cv.drawContours(frame,contours,maxIndex,(0,0,255),2)

        center = width/2
        offset = 50


        twist = Twist()
        if x < center - 50:
            print "左转"
            twist.linear.x = 0.1
            twist.angular.z = 0.7
        elif x>=center - 50 and x <= center + 50:
            print "直行"
            twist.linear.x = 0.2
            twist.angular.z = 0.0
        else:
            print "右转"
            twist.linear.x = 0.15
            twist.angular.z = -0.7

        cmd_vel_Publisher.publish(twist)
        cv.imshow("mask",mask)
        cv.imshow("frame",frame)
        cv.waitKey(35)
        ok, frame = capture.read()


        rate.sleep()