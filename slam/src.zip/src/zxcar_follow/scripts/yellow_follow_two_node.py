#! /usr/bin/env python
# encoding: utf-8
import rospy
from geometry_msgs.msg import Twist
import cv2 as cv
import numpy as np
import math
import sys

DEBUG = True

# 基于颜色提取 黄色车道线
def fetch_yellow(frame):
    # 将彩色图像转成HSV颜色空间
    hsv_img = cv.cvtColor(frame,cv.COLOR_BGR2HSV)

    # 基于范围进行数据的提取
    lowerb = (25,66,56)
    upperb = (35,255,255)
    mask = cv.inRange(hsv_img,lowerb,upperb)

    if DEBUG:
        cv.imshow("color range mask",mask)

    return mask

def fetch_roi(frame):
    """
    提取感兴趣的区域
    :param frame:
    :return:
    """
    height,width = frame.shape[0:2]

    roi = frame[height/2:height,:]

    # 进行形态学变化
    kernel = cv.getStructuringElement(cv.MORPH_RECT,(3,3))
    roi = cv.morphologyEx(roi,cv.MORPH_CLOSE,kernel,iterations=5)

    _, contours, _ = cv.findContours(roi,cv.RETR_EXTERNAL,cv.CHAIN_APPROX_SIMPLE)

    dst = np.zeros_like(roi)
    for i,c in enumerate(contours):
        area = cv.contourArea(c)
        if area>200:
            cv.drawContours(dst,contours,i,255,-1)

    if DEBUG:
        cv.imshow("roi",roi)

    return dst


def fetch_edge(frame):
    """
    提取图像边缘信息
    """
    canny = cv.Canny(frame,200,400)
    if DEBUG:
        cv.imshow("canny",canny)

    return canny

def make_line(lines_kb):
    """
    根据所有KB,计算平均kb, 也就是将多条直线合并成一条直线
    :param lines_kb:
    :return:
    """
    lines_avg_kb = np.average(lines_kb,axis=0)

    avg_k = lines_avg_kb[0]
    avg_b = lines_avg_kb[1]
    # y = kx + b
    # 屏幕底部点
    y1 = 0
    x1 = (y1 - avg_b)/avg_k
    # 屏幕中间的点
    y2 = src_height*0.5
    x2 = (y2 - avg_b)/avg_k

    if x1 < -1e5 or x1 > 1e5: return None
    if x2 < -1e5 or x2 > 1e5: return None

    return [x1,y1,x2,y2]



def fetch_lines(frame):
    """
        提取图像中的直线 ： 霍夫直线
    """
    lines = cv.HoughLinesP(frame,1,np.pi/180,10,minLineLength=40,maxLineGap=5)

    if lines is None:
        return None
    # 存放左边线段的斜率和截距  y = kx + b
    left_kb = []
    right_kb = []

    boundary = 1/3
    left_region_boundary = src_width * (1 - boundary)
    right_region_boundary = src_width * boundary

    for line in lines:
        x1,y1,x2,y2 = line[0]
        # 计算当前线段的斜率和截距 k = (y2 - y1)/(x2-x1)
        if x1 == x2 :
            continue

        params = np.polyfit((x1,x2),(y1,y2),1)
        # 斜率
        k = params[0]
        # 截距
        b = params[1]

        if k < 0: # 左边的线段
            if x1 < left_region_boundary and x2 < left_region_boundary:
                left_kb.append((k,b))
        else:
            if x1 > right_region_boundary and x2 > right_region_boundary:
                right_kb.append((k,b))
        # cv.line(src,(x1,y1+src_height/2),(x2,y2+src_height/2),(0,0,255),2)

    avg_lines = []
    if len(left_kb) > 0:
        left_line = make_line(left_kb)
        if left_line:
            avg_lines.append(left_line)

    if len(right_kb)>0:
        right_line = make_line(right_kb)
        if right_line:
            avg_lines.append(right_line)


    if DEBUG:
        for line in avg_lines:
            x1,y1,x2,y2 = line
            print  line
            cv.line(src,(int(x1),int(y1+src_height/2)),(int(x2),int(y2+src_height/2)),(0,0,255),2)

        # cv.imshow("lines",src)

    return avg_lines

def calc_headline(lines):
    """
    计算小车的引导线
    :param lines: 0条直线  1条： 左边or右边  2：条 左边和右边
    :return:
    """
    if lines is None:
        return None
    if len(lines) == 0:
        return None

    # 引导线的中心点
    x = src_width/2
    y = src_height

    if len(lines) == 1:
        x1,y1,x2,y2 = lines[0]

        x_head = x + (x1 - x2)
        y_head = y2

    elif len(lines) == 2:
        # 左边的线段
        line1_x1,_,line1_x2,y2 = lines[0]
        # 右边的线段
        line2_x1,_,line2_x2,_ = lines[1]

        x_head = (line1_x1 + line2_x1)/2
        y_head = y2

    return [x,y,x_head,y_head]


def calc_radian(x_offset,y_offset):
    # tan(弧度) = x_offset/y_offset
    # atan
    return math.atan(x_offset/y_offset)

intergral = 0
derivative = 0
prev_error = 0

def pid_control(curr,target):
    """
    :param curr:  当前计算出来的弧度
    :param target: 目标弧度
    :return: 角速度
    """
    global intergral,derivative,prev_error
    error = target - curr
    intergral += error
    derivative = prev_error

    # pid的计算公式
    kp = 0.2
    ki = 0.0
    kd = 0.02

    value = kp*error + ki * intergral + kd*derivative
    prev_error = error;

    return value

def shutdown():
    twist = Twist()
    twist.linear.x = 0
    twist.angular.z = 0
    cmd_vel_Publisher.publish(twist)
    print "stop car..."

if __name__ == '__main__':
    # src = cv.imread("/home/itcast/Desktop/env40.jpg")
    # src_height,src_width = src.shape[0:2]
    # cv.imshow("src",src)

    rospy.init_node("yellow_follow_two")

    # 当程序退出
    rospy.on_shutdown(shutdown);

    # ros控制的频率
    rate = rospy.Rate(50)

    # 定义publisher : cmd_vel
    cmd_vel_Publisher = rospy.Publisher("/cmd_vel",Twist,queue_size=1)


    captrue = cv.VideoCapture(0)
    ok,src = captrue.read()
    src_height,src_width = src.shape[0:2]
    # while ok:
    while not rospy.is_shutdown():
        # 基于颜色提取
        yellow_mask = fetch_yellow(src)
        # 提取ROI感兴趣区域
        roi = fetch_roi(yellow_mask)
        # 提取图像的边缘
        edge = fetch_edge(roi)
        # 提取图像中直线
        lines = fetch_lines(edge)
        # 计算小车的引导线
        headline = calc_headline(lines)

        twist = Twist()

        if headline:
            x1,y1,x2,y2 = headline
            x_offset = x2 - src_width/2
            y_offset = y2
            # 弧度
            radian = calc_radian(x_offset,y_offset)


            value = pid_control(radian,0)

            print("弧度：{},最终的角速度：{}".format(radian,value))

            if DEBUG:
                x1,y1,x2,y2 = headline
                cv.line(src,(int(x1),int(y1)),(int(x2),int(y2)),(0,0,255),5)
                cv.imshow("src",src)

            twist.linear.x = 0.1
            twist.angular.z = value*4
        else:
            cv.imshow("src",src)
            twist.linear.x = 0
            twist.angular.z = 0

        cmd_vel_Publisher.publish(twist)

        cv.waitKey(1)
        ok,src = captrue.read()
        rate.sleep()




    cv.waitKey()

# def shutdown():
#     twist = Twist()
#     twist.linear.x = 0
#     twist.angular.z = 0
#     cmd_vel_Publisher.publish(twist)
#     print "stop car..."

# if __name__ == '__main__':
    # rospy.init_node("yellow_follow")
    #
    # # 当程序退出
    # rospy.on_shutdown(shutdown);
    #
    # # ros控制的频率
    # rate = rospy.Rate(100)
    #
    # # 定义publisher : cmd_vel
    # cmd_vel_Publisher = rospy.Publisher("/cmd_vel",Twist,queue_size=1)



    # capture = cv.VideoCapture(0)
    # print capture.isOpened()
    #
    # ok,frame = capture.read()
    #
    # lowerb = (23,43,46)
    # upperb = (34,255,255)
    #
    # height,width = frame.shape[0:2]
    # screen_center = width / 2
    # offset = 50
    # while not rospy.is_shutdown():
    #
    #     # 将图像转成HSV颜色空间
    #     hsv_frame = cv.cvtColor(frame, cv.COLOR_BGR2HSV)
    #     # 基于颜色的物品提取
    #     mask = cv.inRange(hsv_frame,lowerb,upperb)
    #     # 找出面积最大的区域
    #     _,contours,_ = cv.findContours(mask,cv.RETR_EXTERNAL,cv.CHAIN_APPROX_SIMPLE)
    #
    #     maxArea = 0
    #     maxIndex = 0
    #     for i,c in enumerate(contours):
    #         area = cv.contourArea(c)
    #         if area > maxArea:
    #             maxArea = area
    #             maxIndex = i
    #     # 绘制
    #     cv.drawContours(frame,contours,maxIndex,(0,0,255),2)
    #     # 获取外切矩形
    #     x,y,w,h = cv.boundingRect(contours[maxIndex])
    #     cv.rectangle(frame,(x,y),(x+w,y+h),(255,255,0),2)
    #
    #     # 获取外切矩形的中心像素点
    #     center_x = int(x + w/2)
    #     center_y = int(y + h/2)
    #     cv.circle(frame,(center_x,center_y),5,(0,0,255),-1)
    #
    #     # 判断当前小车应该是左转还是右转还是直行
    #     twist = Twist()
    #     if center_x < screen_center - offset:
    #         twist.linear.x = 0.05
    #         twist.angular.z = 0.2
    #         print "turn left"
    #     elif center_x >= screen_center - offset and center_x <= screen_center + offset:
    #         twist.linear.x = 0.1
    #         twist.angular.z = 0.0
    #         print "go"
    #     elif center_x >  screen_center + offset:
    #         twist.linear.x = 0.05
    #         twist.angular.z = -0.2
    #         print "turn right"
    #     else:
    #         twist.linear.x = 0
    #         twist.angular.z = 0
    #         print "stop"
    #
    #     # 将速度信息发送出去
    #     cmd_vel_Publisher.publish(twist)
    #
    #     cv.imshow("mask",mask)
    #     cv.imshow("frame",frame)
    #     cv.waitKey(1)
    #     rate.sleep()
    #
    #     ok, frame = capture.read()
