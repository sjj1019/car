# generated from catkin/cmake/template/pkg.context.pc.in
CATKIN_PACKAGE_PREFIX = ""
PROJECT_PKG_CONFIG_INCLUDE_DIRS = "/home/itcast/Downloads/heima_ws/src/zxcar/include".split(';') if "/home/itcast/Downloads/heima_ws/src/zxcar/include" != "" else []
PROJECT_CATKIN_DEPENDS = "roscpp;rospy;tf;nav_msgs;geometry_msgs;sensor_msgs;std_msgs".replace(';', ' ')
PKG_CONFIG_LIBRARIES_WITH_PREFIX = "-lheimarobot".split(';') if "-lheimarobot" != "" else []
PROJECT_NAME = "zxcar"
PROJECT_SPACE_DIR = "/home/itcast/Downloads/heima_ws/src/zxcar/cmake-build-debug/devel"
PROJECT_VERSION = "0.0.0"
