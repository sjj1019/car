#!/usr/bin/env sh
# generated from catkin/python/catkin/environment_cache.py

# based on a snapshot of the environment before and after calling the setup script
# it emulates the modifications of the setup script without recurring computations

# new environment variables

# modified environment variables
export CMAKE_PREFIX_PATH="/home/itcast/Downloads/heima_ws/src/zxcar_driver/cmake-build-debug/devel:$CMAKE_PREFIX_PATH"
export PATH='/opt/ros/melodic/bin:/home/itcast/anaconda2/condabin:/home/itcast/.local/bin:/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/usr/games:/usr/local/games:/snap/bin'
export ROSLISP_PACKAGE_DIRECTORIES='/home/itcast/Downloads/heima_ws/src/zxcar_driver/cmake-build-debug/devel/share/common-lisp'
export ROS_PACKAGE_PATH="/home/itcast/Downloads/heima_ws/src/zxcar_driver:$ROS_PACKAGE_PATH"